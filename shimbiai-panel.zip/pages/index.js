// React landing page for Shimbi AI Panel
export default function Home() { return <div>Welcome to Shimbi AI</div>; }