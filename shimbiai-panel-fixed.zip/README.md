# Shimbi AI Executive Panel

This is the AI control panel for Shimbi Travel automation.