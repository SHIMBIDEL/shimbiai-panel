export default function Home() {
  return <div>Welcome to Shimbi AI Executive Panel</div>;
}